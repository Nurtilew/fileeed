const express = require('express');
const cors = require('cors');
const path = require('path');
const BankGateways = require('./bank_gateways');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

let state = {
  balance: 50000,
  profit: 0,
  deposits: [],
  withdraws: [],
  history: []
};

const COMMISSION_RATE = Number(process.env.ADMIN_COMMISSION_RATE || 0.05);

app.get('/api/v1/summary', (req, res) => {
  res.json({ success: true, ...state });
});

app.post('/api/v1/deposit', async (req, res) => {
  const { amount, receiptRef, bank } = req.body;
  const numAmount = Number(amount);

  if (!numAmount || !receiptRef) {
    return res.status(400).json({ success: false, message: "Сома мен Чек нөмірін енгізіңіз!" });
  }

  await BankGateways.verifyKaspiPayment(receiptRef, numAmount);

  const dep = { id: 'DEP_' + Date.now(), amount: numAmount, receiptRef, bank: bank || 'Kaspi', status: 'PENDING' };
  state.deposits.push(dep);
  res.json({ success: true, message: "Депозиттік заявка жіберілді!", deposit: dep });
});

app.post('/api/v1/withdraw', async (req, res) => {
  const { amount, cardNumber } = req.body;
  const numAmount = Number(amount);

  if (!numAmount || !cardNumber) {
    return res.status(400).json({ success: false, message: "Сома мен Карта нөмірін жазыңыз!" });
  }

  if (numAmount > state.balance) {
    return res.status(400).json({ success: false, message: "Баланста ақша жеткіліксіз!" });
  }

  const fee = numAmount * COMMISSION_RATE;
  const netPayout = numAmount - fee;

  state.balance -= numAmount;
  await BankGateways.sendFreedomPayout(cardNumber, netPayout);

  const withdraw = { id: 'WITH_' + Date.now(), cardNumber, amount: numAmount, fee, netPayout, status: 'PROCESSING' };
  state.withdraws.push(withdraw);

  res.json({ success: true, message: `Заявка жасалды! Картаға түсетін сома: ${netPayout} ₸ (5% комиссия: ${fee} ₸)`, withdraw });
});

app.post('/api/v1/admin/approve-deposit', (req, res) => {
  const { id } = req.body;
  const idx = state.deposits.findIndex(d => d.id === id);
  if (idx === -1) return res.status(404).json({ success: false, message: "Заявка табылмады" });

  const dep = state.deposits[idx];
  state.balance += dep.amount;
  dep.status = 'APPROVED';
  state.history.push(dep);
  state.deposits.splice(idx, 1);

  res.json({ success: true, message: "Депозит расталды, баланс толтырылды!" });
});

app.post('/api/v1/admin/approve-withdraw', (req, res) => {
  const { id } = req.body;
  const idx = state.withdraws.findIndex(w => w.id === id);
  if (idx === -1) return res.status(404).json({ success: false, message: "Заявка табылмады" });

  const w = state.withdraws[idx];
  state.profit += w.fee;
  w.status = 'COMPLETED';
  state.history.push(w);
  state.withdraws.splice(idx, 1);

  res.json({ success: true, message: "Выплата орындалды, 5% комиссия Таза Пайдаға өтті!" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`P2P Platform Server is active on port ${PORT}`));
